package com.exercise.liquidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiquidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
